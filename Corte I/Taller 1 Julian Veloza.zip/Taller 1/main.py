from superhero import SuperHero
inst_superhero = SuperHero()
inst_superhero.initial_menu()